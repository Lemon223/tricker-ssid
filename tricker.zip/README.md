# CR4CK
Facebook cloning

## Installation
    $ pkg update && pkg upgrade
    $ pkg install git
    $ pkg install ruby
    $ git clone https://github.com/MR-X-Junior/CR4CK
    $ cd CR4CK
    $ gem install user_agent_parser
    $ ruby main.rb
